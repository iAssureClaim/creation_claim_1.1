package exception;

public class QuestionException extends Exception
{

	public QuestionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
